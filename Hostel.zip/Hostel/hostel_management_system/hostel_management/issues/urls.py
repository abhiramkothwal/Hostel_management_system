from django.urls import path
from . import views

urlpatterns = [
    # Issue listing and management
    path('', views.issue_list, name='issue_list'),
    path('my-issues/', views.my_issues, name='my_issues'),
    path('report/', views.report_issue, name='report_issue'),
    path('<int:issue_id>/', views.issue_detail, name='issue_detail'),
    path('<int:issue_id>/update/', views.update_issue, name='update_issue'),
    
    # Comments
    path('<int:issue_id>/comment/', views.add_comment, name='add_comment'),
    
    # Categories
    path('categories/', views.category_list, name='category_list'),
    path('categories/<int:category_id>/', views.category_detail, name='category_detail'),
    
    # Analytics and reports
    path('analytics/', views.issue_analytics, name='issue_analytics'),
] 