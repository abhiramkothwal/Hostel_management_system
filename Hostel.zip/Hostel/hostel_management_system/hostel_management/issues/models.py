from django.db import models
from django.utils import timezone
from django.conf import settings
from accounts.models import User, StudentProfile
from rooms.models import Room, HostelBlock

class IssueCategory(models.Model):
    """Categories for classifying issues"""
    name = models.CharField(max_length=100)
    description = models.TextField(blank=True)
    active = models.BooleanField(default=True)
    
    class Meta:
        verbose_name_plural = "Issue Categories"
    
    def __str__(self):
        return self.name
    
    def get_active_issues_count(self):
        """Return count of active issues in this category"""
        return self.issues.exclude(status__in=['resolved', 'closed']).count()

class Issue(models.Model):
    """Issues reported by users"""
    STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('in_progress', 'In Progress'),
        ('resolved', 'Resolved'),
        ('closed', 'Closed'),
    ]
    
    PRIORITY_CHOICES = [
        ('low', 'Low'),
        ('medium', 'Medium'),
        ('high', 'High'),
        ('urgent', 'Urgent'),
    ]
    
    # Basic info
    title = models.CharField(max_length=200)
    description = models.TextField()
    reported_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='reported_issues')
    
    # Categorization
    category = models.ForeignKey(IssueCategory, on_delete=models.SET_NULL, null=True, related_name='issues')
    priority = models.CharField(max_length=20, choices=PRIORITY_CHOICES, default='medium')
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    
    # Location info
    related_room = models.ForeignKey(Room, on_delete=models.SET_NULL, null=True, blank=True, related_name='issues')
    related_block = models.ForeignKey(HostelBlock, on_delete=models.SET_NULL, null=True, blank=True, related_name='issues')
    
    # Timestamps
    created_at = models.DateTimeField(default=timezone.now)
    updated_at = models.DateTimeField(auto_now=True)
    resolved_at = models.DateTimeField(null=True, blank=True)
    
    # Additional data
    image = models.ImageField(upload_to='issue_images/', blank=True, null=True)
    admin_notes = models.TextField(blank=True)
    
    def __str__(self):
        return self.title
    
    def get_status_badge_class(self):
        """Return Bootstrap badge class based on status"""
        status_classes = {
            'pending': 'bg-warning',
            'in_progress': 'bg-info',
            'resolved': 'bg-success',
            'closed': 'bg-secondary'
        }
        return status_classes.get(self.status, 'bg-secondary')
    
    def get_priority_badge_class(self):
        """Return Bootstrap badge class based on priority"""
        priority_classes = {
            'low': 'bg-info',
            'medium': 'bg-success',
            'high': 'bg-warning',
            'urgent': 'bg-danger'
        }
        return priority_classes.get(self.priority, 'bg-secondary')
    
    def is_active(self):
        """Check if issue is still active (not resolved or closed)"""
        return self.status not in ['resolved', 'closed']
    
    def save(self, *args, **kwargs):
        # Set resolved_at timestamp when status changes to resolved
        if self.status == 'resolved' and not self.resolved_at:
            self.resolved_at = timezone.now()
        super().save(*args, **kwargs)
    
    class Meta:
        ordering = ['-created_at']

class IssueComment(models.Model):
    """Comments on issues"""
    issue = models.ForeignKey(Issue, on_delete=models.CASCADE, related_name='comments')
    author = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='issue_comments')
    content = models.TextField()
    created_at = models.DateTimeField(default=timezone.now)
    
    class Meta:
        ordering = ['created_at']
    
    def __str__(self):
        return f"Comment by {self.author} on {self.issue}"
