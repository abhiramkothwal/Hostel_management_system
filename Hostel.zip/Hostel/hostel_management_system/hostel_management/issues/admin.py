from django.contrib import admin
from .models import IssueCategory, Issue, IssueComment

class IssueCommentInline(admin.TabularInline):
    model = IssueComment
    extra = 0
    readonly_fields = ('author', 'content', 'created_at')

class IssueCategoryAdmin(admin.ModelAdmin):
    list_display = ('name', 'description', 'active')
    list_filter = ('active',)
    search_fields = ('name',)

class IssueAdmin(admin.ModelAdmin):
    list_display = ('title', 'category', 'reported_by', 'status', 'priority', 'created_at')
    list_filter = ('status', 'priority', 'category', 'created_at')
    search_fields = ('title', 'description', 'reported_by__username')
    date_hierarchy = 'created_at'
    readonly_fields = ('created_at', 'updated_at', 'resolved_at')
    inlines = [IssueCommentInline]
    fieldsets = (
        (None, {
            'fields': ('title', 'description', 'reported_by', 'category')
        }),
        ('Status Information', {
            'fields': ('status', 'priority', 'admin_notes', 'resolved_at')
        }),
        ('Location Information', {
            'fields': ('related_room', 'related_block')
        }),
        ('Media', {
            'fields': ('image',)
        }),
        ('Timestamps', {
            'fields': ('created_at', 'updated_at'),
            'classes': ('collapse',)
        })
    )

class IssueCommentAdmin(admin.ModelAdmin):
    list_display = ('issue', 'author', 'created_at')
    list_filter = ('created_at',)
    search_fields = ('issue__title', 'author__username', 'content')
    readonly_fields = ('created_at',)

admin.site.register(IssueCategory, IssueCategoryAdmin)
admin.site.register(Issue, IssueAdmin)
admin.site.register(IssueComment, IssueCommentAdmin)
