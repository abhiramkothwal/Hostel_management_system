from django import forms
from django.utils import timezone
from .models import Issue, IssueComment, IssueCategory
from rooms.models import Room, HostelBlock

class IssueReportForm(forms.ModelForm):
    """Form for reporting a new issue"""
    class Meta:
        model = Issue
        fields = ['title', 'description', 'priority', 'category', 'related_block', 'related_room', 'image']
        widgets = {
            'description': forms.Textarea(attrs={'rows': 4}),
            'category': forms.Select(attrs={'class': 'form-select'}),
            'priority': forms.Select(attrs={'class': 'form-select'}),
        }
    
    def __init__(self, *args, **kwargs):
        self.user = kwargs.pop('user', None)
        super().__init__(*args, **kwargs)
        
        # Make some fields optional
        self.fields['related_block'].required = False
        self.fields['related_room'].required = False
        self.fields['image'].required = False
        
        # Explicitly load categories and ensure they're accessible
        # Force evaluation of queryset to debug if categories exist
        categories = list(IssueCategory.objects.filter(active=True))
        self.fields['category'].queryset = IssueCategory.objects.filter(active=True)
        self.fields['category'].empty_label = None  # Don't allow empty selection
        
        # Add helpful labels
        self.fields['category'].label = "Issue Type"
        self.fields['priority'].label = "Issue Priority"
        
        # Filter blocks the user has access to
        if self.user:
            self.fields['related_block'].queryset = HostelBlock.objects.all()
            
            # If user is a student with an allocated room, pre-select their block and room
            if hasattr(self.user, 'student_profile') and hasattr(self.user.student_profile, 'room_allocations'):
                current_allocation = self.user.student_profile.room_allocations.filter(is_active=True).first()
                if current_allocation:
                    self.fields['related_room'].initial = current_allocation.room
                    self.fields['related_block'].initial = current_allocation.room.hostel_block
    
    def save(self, commit=True):
        instance = super().save(False)
        instance.reported_by = self.user
        instance.created_at = timezone.now()
        
        if commit:
            instance.save()
        return instance

class IssueStatusUpdateForm(forms.ModelForm):
    """Form for updating the status of an issue (admin/warden only)"""
    class Meta:
        model = Issue
        fields = ['status', 'priority', 'admin_notes']
        widgets = {
            'admin_notes': forms.Textarea(attrs={'rows': 3}),
        }

class IssueCommentForm(forms.ModelForm):
    """Form for adding a comment to an issue"""
    class Meta:
        model = IssueComment
        fields = ['content']
        widgets = {
            'content': forms.Textarea(attrs={'rows': 3, 'placeholder': 'Add your comment here...'}),
        }
    
    def __init__(self, *args, **kwargs):
        self.user = kwargs.pop('user', None)
        self.issue = kwargs.pop('issue', None)
        super().__init__(*args, **kwargs)
    
    def save(self, commit=True):
        instance = super().save(False)
        instance.author = self.user
        instance.issue = self.issue
        instance.created_at = timezone.now()
        
        if commit:
            instance.save()
        return instance

class IssueFilterForm(forms.Form):
    """Form for filtering issues"""
    STATUS_CHOICES = (
        ('', 'All Statuses'),
        ('pending', 'Pending'),
        ('in_progress', 'In Progress'),
        ('resolved', 'Resolved'),
        ('closed', 'Closed'),
    )
    
    PRIORITY_CHOICES = (
        ('', 'All Priorities'),
        ('low', 'Low'),
        ('medium', 'Medium'),
        ('high', 'High'),
        ('urgent', 'Urgent'),
    )
    
    status = forms.ChoiceField(choices=STATUS_CHOICES, required=False)
    priority = forms.ChoiceField(choices=PRIORITY_CHOICES, required=False)
    category = forms.ModelChoiceField(
        queryset=IssueCategory.objects.all(),
        required=False,
        empty_label="All Categories"
    )
    related_block = forms.ModelChoiceField(
        queryset=HostelBlock.objects.all(),
        required=False,
        empty_label="All Blocks"
    ) 