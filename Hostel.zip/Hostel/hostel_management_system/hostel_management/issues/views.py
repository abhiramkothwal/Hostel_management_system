from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.utils import timezone
from django.db.models import Count
from .models import Issue, IssueCategory, IssueComment
from .forms import IssueReportForm, IssueStatusUpdateForm, IssueCommentForm, IssueFilterForm
from rooms.models import Room, HostelBlock

@login_required
def issue_list(request):
    """Display list of all issues with filters"""
    issues = Issue.objects.all().order_by('-created_at')
    form = IssueFilterForm(request.GET or None)
    
    if form.is_valid():
        if form.cleaned_data.get('status'):
            issues = issues.filter(status=form.cleaned_data['status'])
        if form.cleaned_data.get('priority'):
            issues = issues.filter(priority=form.cleaned_data['priority'])
        if form.cleaned_data.get('category'):
            issues = issues.filter(category=form.cleaned_data['category'])
        if form.cleaned_data.get('related_block'):
            issues = issues.filter(related_block=form.cleaned_data['related_block'])
    
    # Regular users (students) can only see their own issues
    if request.user.is_student():
        issues = issues.filter(reported_by=request.user)
    
    return render(request, 'issues/issue_list.html', {
        'issues': issues,
        'form': form
    })

@login_required
def my_issues(request):
    """Display issues reported by the current user"""
    issues = Issue.objects.filter(reported_by=request.user).order_by('-created_at')
    
    return render(request, 'issues/my_issues.html', {
        'issues': issues
    })

@login_required
def report_issue(request):
    """Report a new issue"""
    if request.method == 'POST':
        form = IssueReportForm(request.POST, request.FILES, user=request.user)
        if form.is_valid():
            issue = form.save()
            messages.success(request, "Your issue has been reported successfully.")
            return redirect('issue_detail', issue_id=issue.id)
    else:
        form = IssueReportForm(user=request.user)
    
    return render(request, 'issues/report_issue.html', {
        'form': form
    })

@login_required
def issue_detail(request, issue_id):
    """Display details of a specific issue"""
    issue = get_object_or_404(Issue, pk=issue_id)
    
    # Regular users (students) can only see their own issues
    if request.user.is_student() and issue.reported_by != request.user:
        messages.error(request, "You don't have permission to view this issue.")
        return redirect('my_issues')
    
    comments = issue.comments.all().order_by('created_at')
    comment_form = IssueCommentForm(user=request.user, issue=issue)
    
    return render(request, 'issues/issue_detail.html', {
        'issue': issue,
        'comments': comments,
        'comment_form': comment_form
    })

@login_required
def update_issue(request, issue_id):
    """Update the status of an issue (admin/warden only)"""
    if not (request.user.is_warden() or request.user.is_hostel_admin()):
        messages.error(request, "You don't have permission to update issues.")
        return redirect('issue_list')
    
    issue = get_object_or_404(Issue, pk=issue_id)
    
    if request.method == 'POST':
        form = IssueStatusUpdateForm(request.POST, instance=issue)
        if form.is_valid():
            updated_issue = form.save()
            
            # If status changed to resolved, add timestamp
            if updated_issue.status == 'resolved' and not updated_issue.resolved_at:
                updated_issue.resolved_at = timezone.now()
                updated_issue.save()
            
            messages.success(request, "Issue has been updated successfully.")
            return redirect('issue_detail', issue_id=issue.id)
    else:
        form = IssueStatusUpdateForm(instance=issue)
    
    return render(request, 'issues/update_issue.html', {
        'form': form,
        'issue': issue
    })

@login_required
def add_comment(request, issue_id):
    """Add a comment to an issue"""
    issue = get_object_or_404(Issue, pk=issue_id)
    
    # Regular users (students) can only comment on their own issues
    if request.user.is_student() and issue.reported_by != request.user:
        messages.error(request, "You don't have permission to comment on this issue.")
        return redirect('my_issues')
    
    if request.method == 'POST':
        form = IssueCommentForm(request.POST, user=request.user, issue=issue)
        if form.is_valid():
            form.save()
            messages.success(request, "Your comment has been added successfully.")
    
    return redirect('issue_detail', issue_id=issue.id)

@login_required
def category_list(request):
    """List all issue categories with issue counts"""
    if not (request.user.is_warden() or request.user.is_hostel_admin()):
        messages.error(request, "You don't have permission to view issue categories.")
        return redirect('issue_list')
    
    categories = IssueCategory.objects.annotate(
        issues_count=Count('issues')
    ).order_by('name')
    
    return render(request, 'issues/category_list.html', {
        'categories': categories
    })

@login_required
def category_detail(request, category_id):
    """Display details and issues for a specific category"""
    if not (request.user.is_warden() or request.user.is_hostel_admin()):
        messages.error(request, "You don't have permission to view issue categories.")
        return redirect('issue_list')
    
    category = get_object_or_404(IssueCategory, pk=category_id)
    issues = Issue.objects.filter(category=category).order_by('-created_at')
    
    return render(request, 'issues/category_detail.html', {
        'category': category,
        'issues': issues
    })

@login_required
def issue_analytics(request):
    """Display analytics and reports for issues"""
    if not (request.user.is_warden() or request.user.is_hostel_admin()):
        messages.error(request, "You don't have permission to view issue analytics.")
        return redirect('issue_list')
    
    # Issues by status
    issues_by_status = Issue.objects.values('status').annotate(
        count=Count('id')
    ).order_by('status')
    
    # Issues by category
    issues_by_category = Issue.objects.values('category__name').annotate(
        count=Count('id')
    ).order_by('-count')
    
    # Issues by priority
    issues_by_priority = Issue.objects.values('priority').annotate(
        count=Count('id')
    ).order_by('priority')
    
    # Issues by block
    issues_by_block = Issue.objects.filter(related_block__isnull=False).values(
        'related_block__name'
    ).annotate(
        count=Count('id')
    ).order_by('-count')
    
    # Resolution time (days) for resolved issues
    resolved_issues = Issue.objects.filter(
        status='resolved',
        resolved_at__isnull=False
    )
    
    resolution_time_data = []
    for issue in resolved_issues:
        resolution_time = (issue.resolved_at.date() - issue.created_at.date()).days
        resolution_time_data.append({
            'issue': issue,
            'days': resolution_time
        })
    
    return render(request, 'issues/issue_analytics.html', {
        'issues_by_status': issues_by_status,
        'issues_by_category': issues_by_category,
        'issues_by_priority': issues_by_priority,
        'issues_by_block': issues_by_block,
        'resolution_time_data': resolution_time_data
    })
