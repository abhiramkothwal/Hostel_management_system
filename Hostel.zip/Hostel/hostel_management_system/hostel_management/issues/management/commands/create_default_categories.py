from django.core.management.base import BaseCommand
from issues.models import IssueCategory

class Command(BaseCommand):
    help = 'Creates default issue categories if none exist'

    def handle(self, *args, **kwargs):
        # Define default categories
        default_categories = [
            {
                'name': 'Plumbing',
                'description': 'Issues related to water supply, leaks, drains, etc.'
            },
            {
                'name': 'Electrical',
                'description': 'Issues with lights, power outlets, electrical equipment, etc.'
            },
            {
                'name': 'Furniture',
                'description': 'Problems with beds, desks, chairs, wardrobes, etc.'
            },
            {
                'name': 'Cleaning',
                'description': 'Issues related to room cleanliness, common areas, etc.'
            },
            {
                'name': 'Security',
                'description': 'Issues related to door locks, windows, safety concerns, etc.'
            },
            {
                'name': 'Internet',
                'description': 'Problems with WiFi, internet connectivity, etc.'
            },
            {
                'name': 'Maintenance',
                'description': 'General maintenance issues like painting, tiles, etc.'
            },
            {
                'name': 'Air Conditioning',
                'description': 'Issues with AC units, heating systems, etc.'
            },
            {
                'name': 'Other',
                'description': 'Any other issues not covered by other categories'
            }
        ]
        
        # Count existing categories
        existing_count = IssueCategory.objects.count()
        
        if existing_count == 0:
            self.stdout.write(self.style.WARNING('No issue categories found. Creating defaults...'))
            
            # Create default categories
            for category in default_categories:
                IssueCategory.objects.create(
                    name=category['name'],
                    description=category['description'],
                    active=True
                )
                self.stdout.write(f"Created category: {category['name']}")
            
            self.stdout.write(self.style.SUCCESS(f'Successfully created {len(default_categories)} default categories'))
        else:
            self.stdout.write(self.style.SUCCESS(f'Found {existing_count} existing categories. No action taken.')) 