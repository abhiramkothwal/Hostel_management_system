from django.db import models
from django.utils import timezone
from django.conf import settings
from rooms.models import HostelBlock

class Announcement(models.Model):
    """Announcements for students and staff"""
    IMPORTANCE_CHOICES = [
        ('normal', 'Normal'),
        ('important', 'Important'),
        ('urgent', 'Urgent'),
    ]
    
    TARGET_AUDIENCE_CHOICES = [
        ('all', 'All Users'),
        ('students', 'Students Only'),
        ('staff', 'Staff Only'),
    ]
    
    CATEGORY_CHOICES = [
        ('general', 'General'),
        ('maintenance', 'Maintenance'),
        ('events', 'Events'),
        ('rules', 'Rules and Regulations'),
        ('fees', 'Fees and Payments'),
    ]
    
    # Basic information
    title = models.CharField(max_length=200)
    content = models.TextField()
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='created_announcements')
    created_at = models.DateTimeField(default=timezone.now)
    
    # Classification
    category = models.CharField(max_length=20, choices=CATEGORY_CHOICES, default='general')
    importance = models.CharField(max_length=10, choices=IMPORTANCE_CHOICES, default='normal')
    target_audience = models.CharField(max_length=10, choices=TARGET_AUDIENCE_CHOICES, default='all')
    
    # Status
    is_active = models.BooleanField(default=True)
    
    # Targeting options
    for_all_students = models.BooleanField(default=True)
    for_specific_blocks = models.ManyToManyField(HostelBlock, blank=True)
    
    # Attachment
    attachment = models.FileField(upload_to='announcements/', blank=True, null=True)
    
    # Expiry
    expires_at = models.DateTimeField(blank=True, null=True)
    
    class Meta:
        ordering = ['-created_at']
    
    def __str__(self):
        return self.title
    
    def get_importance_badge_class(self):
        """Return Bootstrap badge class based on importance"""
        importance_classes = {
            'normal': 'bg-info',
            'important': 'bg-warning',
            'urgent': 'bg-danger'
        }
        return importance_classes.get(self.importance, 'bg-secondary')
    
    @property
    def short_content(self):
        """Return a shortened version of the content for display in lists"""
        if len(self.content) > 100:
            return f"{self.content[:100]}..."
        return self.content

class AnnouncementReadStatus(models.Model):
    """Tracks which announcements have been read by which users"""
    announcement = models.ForeignKey(Announcement, on_delete=models.CASCADE, related_name='read_status')
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='announcement_read_status')
    read_at = models.DateTimeField(default=timezone.now)
    
    class Meta:
        unique_together = ['announcement', 'user']
        verbose_name_plural = 'Announcement Read Statuses'
    
    def __str__(self):
        return f"{self.user} read {self.announcement} at {self.read_at}"
