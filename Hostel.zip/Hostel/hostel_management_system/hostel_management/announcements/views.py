from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.utils import timezone
from .models import Announcement, AnnouncementReadStatus
from .forms import AnnouncementForm

@login_required
def announcement_list(request):
    """List all announcements with unread status for current user"""
    # Get all active announcements
    announcements = Announcement.objects.filter(is_active=True).order_by('-created_at')
    
    # Get read status for current user
    read_status = {}
    if request.user:
        read_statuses = AnnouncementReadStatus.objects.filter(
            user=request.user,
            announcement__in=announcements
        )
        read_status = {rs.announcement_id: rs for rs in read_statuses}
    
    # Mark announcements as read or unread
    for announcement in announcements:
        announcement.is_read = announcement.id in read_status
    
    return render(request, 'announcements/announcement_list.html', {
        'announcements': announcements
    })

@login_required
def announcement_detail(request, announcement_id):
    """Show details of a specific announcement"""
    announcement = get_object_or_404(Announcement, pk=announcement_id)
    
    # Mark as read if not already read
    read_status, created = AnnouncementReadStatus.objects.get_or_create(
        user=request.user,
        announcement=announcement
    )
    
    if created:
        read_status.read_at = timezone.now()
        read_status.save()
    
    return render(request, 'announcements/announcement_detail.html', {
        'announcement': announcement
    })

@login_required
def create_announcement(request):
    """Create a new announcement (admin/warden only)"""
    if not (request.user.is_hostel_admin() or request.user.is_warden()):
        messages.error(request, "You don't have permission to create announcements.")
        return redirect('announcement_list')
    
    if request.method == 'POST':
        form = AnnouncementForm(request.POST, user=request.user)
        if form.is_valid():
            announcement = form.save()
            messages.success(request, "Announcement has been created successfully.")
            return redirect('announcement_detail', announcement_id=announcement.id)
    else:
        form = AnnouncementForm(user=request.user)
    
    return render(request, 'announcements/create_announcement.html', {
        'form': form
    })

@login_required
def edit_announcement(request, announcement_id):
    """Edit an existing announcement (admin/warden only)"""
    if not (request.user.is_hostel_admin() or request.user.is_warden()):
        messages.error(request, "You don't have permission to edit announcements.")
        return redirect('announcement_list')
    
    announcement = get_object_or_404(Announcement, pk=announcement_id)
    
    if request.method == 'POST':
        form = AnnouncementForm(request.POST, instance=announcement, user=request.user)
        if form.is_valid():
            form.save()
            messages.success(request, "Announcement has been updated successfully.")
            return redirect('announcement_detail', announcement_id=announcement.id)
    else:
        form = AnnouncementForm(instance=announcement, user=request.user)
    
    return render(request, 'announcements/edit_announcement.html', {
        'form': form,
        'announcement': announcement
    })

@login_required
def delete_announcement(request, announcement_id):
    """Delete an announcement (admin/warden only)"""
    if not (request.user.is_hostel_admin() or request.user.is_warden()):
        messages.error(request, "You don't have permission to delete announcements.")
        return redirect('announcement_list')
    
    announcement = get_object_or_404(Announcement, pk=announcement_id)
    
    if request.method == 'POST':
        announcement.is_active = False
        announcement.save()
        messages.success(request, "Announcement has been deleted successfully.")
        return redirect('announcement_list')
    
    return render(request, 'announcements/delete_announcement.html', {
        'announcement': announcement
    })

@login_required
def mark_announcement_read(request, announcement_id):
    """Mark an announcement as read for the current user"""
    announcement = get_object_or_404(Announcement, pk=announcement_id)
    
    read_status, created = AnnouncementReadStatus.objects.get_or_create(
        user=request.user,
        announcement=announcement
    )
    
    if created:
        read_status.read_at = timezone.now()
        read_status.save()
    
    # Redirect back to referring page or list
    next_url = request.GET.get('next', 'announcement_list')
    return redirect(next_url)
