from django import forms
from .models import Announcement
from rooms.models import HostelBlock

class AnnouncementForm(forms.ModelForm):
    """Form for creating and editing announcements"""
    class Meta:
        model = Announcement
        fields = ['title', 'content', 'category', 'importance', 'target_audience']
        widgets = {
            'content': forms.Textarea(attrs={'rows': 5}),
        }
    
    def __init__(self, *args, **kwargs):
        self.user = kwargs.pop('user', None)
        super().__init__(*args, **kwargs)
        
        # Add Bootstrap classes
        for field in self.fields.values():
            if isinstance(field.widget, forms.Textarea):
                field.widget.attrs.update({'class': 'form-control'})
            elif isinstance(field.widget, forms.Select):
                field.widget.attrs.update({'class': 'form-select'})
    
    def save(self, commit=True):
        instance = super().save(commit=False)
        if self.user:
            instance.created_by = self.user
        
        if commit:
            instance.save()
        
        return instance

class AnnouncementFilterForm(forms.Form):
    active_only = forms.BooleanField(required=False, initial=True, label="Show Active Only")
    block = forms.ModelChoiceField(
        queryset=HostelBlock.objects.all(),
        required=False,
        empty_label="All Blocks"
    ) 