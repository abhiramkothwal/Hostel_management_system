from django.contrib import admin
from .models import Announcement, AnnouncementReadStatus

class AnnouncementReadStatusInline(admin.TabularInline):
    model = AnnouncementReadStatus
    extra = 0
    readonly_fields = ('user', 'read_at')
    can_delete = False
    max_num = 0

class AnnouncementAdmin(admin.ModelAdmin):
    list_display = ('title', 'created_by', 'created_at', 'category', 'importance', 'is_active', 'read_count')
    list_filter = ('is_active', 'created_at', 'category', 'importance', 'target_audience')
    search_fields = ('title', 'content', 'created_by__username')
    readonly_fields = ('created_at',)
    date_hierarchy = 'created_at'
    inlines = [AnnouncementReadStatusInline]
    
    def read_count(self, obj):
        return obj.read_status.count()
    read_count.short_description = 'Times Read'

class AnnouncementReadStatusAdmin(admin.ModelAdmin):
    list_display = ('announcement', 'user', 'read_at')
    list_filter = ('read_at',)
    search_fields = ('announcement__title', 'user__username')
    date_hierarchy = 'read_at'
    readonly_fields = ('read_at',)

admin.site.register(Announcement, AnnouncementAdmin)
admin.site.register(AnnouncementReadStatus, AnnouncementReadStatusAdmin)
