from django.urls import path
from . import views

urlpatterns = [
    path('', views.announcement_list, name='announcement_list'),
    path('<int:announcement_id>/', views.announcement_detail, name='announcement_detail'),
    path('create/', views.create_announcement, name='create_announcement'),
    path('<int:announcement_id>/edit/', views.edit_announcement, name='edit_announcement'),
    path('<int:announcement_id>/delete/', views.delete_announcement, name='delete_announcement'),
    path('<int:announcement_id>/mark-read/', views.mark_announcement_read, name='mark_announcement_read'),
] 