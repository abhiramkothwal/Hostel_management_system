from django.contrib import admin
from .models import Notification, SystemStatistics

class NotificationAdmin(admin.ModelAdmin):
    list_display = ('title', 'user', 'is_read', 'created_at')
    list_filter = ('is_read', 'created_at')
    search_fields = ('title', 'message', 'user__username')
    readonly_fields = ('created_at',)
    date_hierarchy = 'created_at'

class SystemStatisticsAdmin(admin.ModelAdmin):
    list_display = ('date', 'total_students', 'total_rooms', 'occupied_rooms', 'available_rooms', 'pending_issues', 'resolved_issues')
    list_filter = ('date',)
    date_hierarchy = 'date'
    readonly_fields = ('date',)

admin.site.register(Notification, NotificationAdmin)
admin.site.register(SystemStatistics, SystemStatisticsAdmin)
