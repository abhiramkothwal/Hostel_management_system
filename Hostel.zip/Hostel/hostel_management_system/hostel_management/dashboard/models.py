from django.db import models
from accounts.models import User

# Create your models here.

class Notification(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='notifications')
    title = models.CharField(max_length=255)
    message = models.TextField()
    is_read = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    
    # Related content links
    link = models.CharField(max_length=255, blank=True, null=True)
    
    class Meta:
        ordering = ['-created_at']
    
    def __str__(self):
        return f"{self.title} - {self.user.username}"
        
    def mark_as_read(self):
        self.is_read = True
        self.save()
        
class SystemStatistics(models.Model):
    date = models.DateField(auto_now_add=True, unique=True)
    total_students = models.PositiveIntegerField(default=0)
    total_rooms = models.PositiveIntegerField(default=0)
    occupied_rooms = models.PositiveIntegerField(default=0)
    available_rooms = models.PositiveIntegerField(default=0)
    pending_issues = models.PositiveIntegerField(default=0)
    resolved_issues = models.PositiveIntegerField(default=0)
    
    class Meta:
        verbose_name_plural = "System Statistics"
        get_latest_by = "date"
        
    def __str__(self):
        return f"Statistics for {self.date}"
