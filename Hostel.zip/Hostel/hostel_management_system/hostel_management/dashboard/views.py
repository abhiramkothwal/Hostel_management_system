from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.db.models import Count, Q
from django.utils import timezone
import json

from .models import Notification, SystemStatistics
from accounts.models import User, StudentProfile, WardenProfile
from rooms.models import Room, RoomAllocation, RoomChangeRequest, HostelBlock
from issues.models import Issue
from announcements.models import Announcement, AnnouncementReadStatus

@login_required
def dashboard(request):
    user = request.user
    context = {}
    
    # Common data for all users
    context['recent_announcements'] = Announcement.objects.filter(is_active=True).order_by('-created_at')[:5]
    context['unread_notifications_count'] = Notification.objects.filter(user=user, is_read=False).count()
    context['recent_notifications'] = Notification.objects.filter(user=user).order_by('-created_at')[:5]
    
    # Add is_read_by_user flag to announcements
    for announcement in context['recent_announcements']:
        read_status = AnnouncementReadStatus.objects.filter(announcement=announcement, user=user).exists()
        announcement.is_read_by_user = read_status
    
    # Student-specific data
    if user.is_student():
        try:
            student_profile = user.student_profile
            active_allocation = RoomAllocation.objects.filter(student=student_profile, is_active=True).first()
            
            if active_allocation:
                context['current_room'] = active_allocation.room
            else:
                context['current_room'] = None
            
            context['pending_issues_count'] = Issue.objects.filter(
                reported_by=user,
                status__in=['pending', 'in_progress']
            ).count()
            
            context['change_requests_count'] = RoomChangeRequest.objects.filter(
                student=student_profile,
                status='pending'
            ).count()
            
            context['unread_announcements_count'] = Announcement.objects.filter(
                is_active=True
            ).exclude(
                read_status__user=user
            ).count()
            
            context['recent_issues'] = Issue.objects.filter(
                reported_by=user
            ).order_by('-created_at')[:5]
            
        except StudentProfile.DoesNotExist:
            # Handle case where student profile doesn't exist
            pass
    
    # Warden and Admin-specific data
    elif user.is_warden() or user.is_hostel_admin():
        context['students_count'] = User.objects.filter(user_type='student').count()
        context['total_rooms_count'] = Room.objects.count()
        context['rooms_occupied_count'] = Room.objects.exclude(status='available').count()
        
        all_issues = Issue.objects.all()
        pending_issues = all_issues.filter(status__in=['pending', 'in_progress'])
        context['pending_issues_count'] = pending_issues.count()
        
        if all_issues.count() > 0:
            context['pending_issues_percentage'] = (pending_issues.count() / all_issues.count()) * 100
        else:
            context['pending_issues_percentage'] = 0
            
        context['pending_change_requests_count'] = RoomChangeRequest.objects.filter(status='pending').count()
        
        context['recent_issues'] = Issue.objects.all().order_by('-created_at')[:5]
        
        # Prepare data for room occupancy chart
        blocks = HostelBlock.objects.all()
        block_names = [block.name for block in blocks]
        total_rooms_by_block = []
        occupied_rooms_by_block = []
        
        for block in blocks:
            total_rooms = Room.objects.filter(hostel_block=block).count()
            occupied_rooms = Room.objects.filter(hostel_block=block).exclude(status='available').count()
            
            total_rooms_by_block.append(total_rooms)
            occupied_rooms_by_block.append(occupied_rooms)
        
        context['block_names'] = json.dumps(block_names)
        context['total_rooms_by_block'] = json.dumps(total_rooms_by_block)
        context['occupied_rooms_by_block'] = json.dumps(occupied_rooms_by_block)
        
        # Prepare data for issues chart
        issues_by_status = [
            Issue.objects.filter(status='pending').count(),
            Issue.objects.filter(status='in_progress').count(),
            Issue.objects.filter(status='resolved').count(),
            Issue.objects.filter(status='closed').count()
        ]
        
        context['issues_by_status'] = json.dumps(issues_by_status)
    
    return render(request, 'dashboard/dashboard.html', context)

@login_required
def notifications(request):
    notifications = Notification.objects.filter(user=request.user).order_by('-created_at')
    unread_count = notifications.filter(is_read=False).count()
    
    return render(request, 'dashboard/notifications.html', {
        'notifications': notifications,
        'unread_count': unread_count
    })

@login_required
def mark_notification_read(request, notification_id):
    notification = get_object_or_404(Notification, id=notification_id, user=request.user)
    notification.mark_as_read()
    
    # Redirect to the notification's link if available, otherwise return to notifications list
    if notification.link:
        return redirect(notification.link)
    return redirect('notifications')

@login_required
def mark_all_notifications_read(request):
    Notification.objects.filter(user=request.user, is_read=False).update(is_read=True)
    return redirect('notifications')

@login_required
def statistics(request):
    # Only allow wardens and admins
    if not (request.user.is_warden() or request.user.is_hostel_admin()):
        return redirect('dashboard')
    
    # Get or create today's statistics
    today = timezone.now().date()
    stats, created = SystemStatistics.objects.get_or_create(date=today)
    
    # Update statistics if needed
    stats.total_students = User.objects.filter(user_type='student').count()
    stats.total_rooms = Room.objects.count()
    stats.occupied_rooms = Room.objects.exclude(status='available').count()
    stats.available_rooms = Room.objects.filter(status='available').count()
    stats.pending_issues = Issue.objects.filter(status__in=['pending', 'in_progress']).count()
    stats.resolved_issues = Issue.objects.filter(status__in=['resolved', 'closed']).count()
    stats.save()
    
    # Get historical data for charts
    historical_stats = SystemStatistics.objects.order_by('date')[:30]  # Last 30 data points
    
    # Prepare data for charts
    dates = [stat.date.strftime('%d %b') for stat in historical_stats]
    occupancy_data = [stat.occupied_rooms for stat in historical_stats]
    issues_pending = [stat.pending_issues for stat in historical_stats]
    issues_resolved = [stat.resolved_issues for stat in historical_stats]
    
    # Get room occupancy by floor
    floors = Room.objects.values_list('floor', flat=True).distinct().order_by('floor')
    floor_occupancy = []
    
    for floor in floors:
        total = Room.objects.filter(floor=floor).count()
        occupied = Room.objects.filter(floor=floor).exclude(status='available').count()
        floor_occupancy.append({
            'floor': floor,
            'total': total,
            'occupied': occupied,
            'percentage': (occupied / total * 100) if total > 0 else 0
        })
    
    # Get issue categories statistics
    issue_categories = Issue.objects.values('category__name').annotate(
        count=Count('id')
    ).order_by('-count')[:5]
    
    context = {
        'stats': stats,
        'dates_json': json.dumps(dates),
        'occupancy_json': json.dumps(occupancy_data),
        'issues_pending_json': json.dumps(issues_pending),
        'issues_resolved_json': json.dumps(issues_resolved),
        'floor_occupancy': floor_occupancy,
        'issue_categories': issue_categories,
    }
    
    return render(request, 'dashboard/statistics.html', context)

@login_required
def student_overview(request):
    # Only allow wardens and admins
    if not (request.user.is_warden() or request.user.is_hostel_admin()):
        return redirect('dashboard')
    
    students = User.objects.filter(user_type='student')
    students_with_rooms = []
    
    for student in students:
        try:
            profile = student.student_profile
            allocation = RoomAllocation.objects.filter(student=profile, is_active=True).first()
            
            student_data = {
                'user': student,
                'profile': profile,
                'allocation': allocation,
                'room': allocation.room if allocation else None,
                'issues_count': Issue.objects.filter(reported_by=student).count(),
                'pending_issues': Issue.objects.filter(reported_by=student, status__in=['pending', 'in_progress']).count()
            }
            
            students_with_rooms.append(student_data)
        except StudentProfile.DoesNotExist:
            continue
    
    return render(request, 'dashboard/student_overview.html', {
        'students': students_with_rooms
    })

@login_required
def warden_overview(request):
    # Only allow admins
    if not request.user.is_hostel_admin():
        return redirect('dashboard')
    
    wardens = User.objects.filter(user_type='warden')
    wardens_with_blocks = []
    
    for warden in wardens:
        try:
            profile = warden.warden_profile
            blocks = HostelBlock.objects.filter(warden=warden)
            
            # Get issues related to the blocks this warden manages
            block_issues = Issue.objects.filter(related_block__in=blocks)
            pending_block_issues = block_issues.filter(status__in=['pending', 'in_progress'])
            
            warden_data = {
                'user': warden,
                'profile': profile,
                'blocks': blocks,
                'blocks_count': blocks.count(),
                'assigned_issues': block_issues.count(),
                'pending_issues': pending_block_issues.count()
            }
            
            wardens_with_blocks.append(warden_data)
        except WardenProfile.DoesNotExist:
            continue
    
    return render(request, 'dashboard/warden_overview.html', {
        'wardens': wardens_with_blocks
    })
