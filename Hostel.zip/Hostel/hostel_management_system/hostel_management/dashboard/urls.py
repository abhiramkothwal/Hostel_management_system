from django.urls import path
from . import views

urlpatterns = [
    path('', views.dashboard, name='dashboard'),
    path('notifications/', views.notifications, name='notifications'),
    path('notifications/<int:notification_id>/read/', views.mark_notification_read, name='mark_notification_read'),
    path('notifications/read-all/', views.mark_all_notifications_read, name='mark_all_notifications_read'),
    path('statistics/', views.statistics, name='statistics'),
    path('student-overview/', views.student_overview, name='student_overview'),
    path('warden-overview/', views.warden_overview, name='warden_overview'),
] 