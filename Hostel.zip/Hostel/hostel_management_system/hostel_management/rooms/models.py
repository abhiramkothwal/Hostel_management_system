from django.db import models
from accounts.models import User, StudentProfile

class HostelBlock(models.Model):
    name = models.CharField(max_length=100)
    warden = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, 
                              limit_choices_to={'user_type': 'warden'})
    description = models.TextField(blank=True, null=True)
    floors = models.PositiveIntegerField(default=1)
    
    def __str__(self):
        return self.name

class Room(models.Model):
    ROOM_TYPE_CHOICES = (
        ('single', 'Single'),
        ('double', 'Double'),
        ('triple', 'Triple'),
        ('quad', 'Quad'),
    )
    
    STATUS_CHOICES = (
        ('available', 'Available'),
        ('partially_occupied', 'Partially Occupied'),
        ('fully_occupied', 'Fully Occupied'),
        ('under_maintenance', 'Under Maintenance'),
    )
    
    room_number = models.CharField(max_length=10)
    hostel_block = models.ForeignKey(HostelBlock, on_delete=models.CASCADE, related_name='rooms')
    floor = models.PositiveIntegerField()
    room_type = models.CharField(max_length=10, choices=ROOM_TYPE_CHOICES)
    capacity = models.PositiveIntegerField()
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='available')
    facilities = models.TextField(blank=True, null=True)
    
    class Meta:
        unique_together = ['room_number', 'hostel_block']
    
    def __str__(self):
        return f"{self.hostel_block.name} - {self.room_number}"
    
    def current_occupancy(self):
        return self.allocations.filter(is_active=True).count()
    
    def update_status(self):
        occupancy = self.current_occupancy()
        if occupancy == 0:
            self.status = 'available'
        elif occupancy < self.capacity:
            self.status = 'partially_occupied'
        elif occupancy >= self.capacity:
            self.status = 'fully_occupied'
        self.save()

class RoomAllocation(models.Model):
    student = models.ForeignKey(StudentProfile, on_delete=models.CASCADE, related_name='room_allocations')
    room = models.ForeignKey(Room, on_delete=models.CASCADE, related_name='allocations')
    allocated_date = models.DateField(auto_now_add=True)
    vacated_date = models.DateField(null=True, blank=True)
    is_active = models.BooleanField(default=True)
    
    def __str__(self):
        return f"{self.student.user.username} - {self.room.room_number}"
    
    def save(self, *args, **kwargs):
        # When saving a new allocation, update the room status
        super().save(*args, **kwargs)
        self.room.update_status()
    
    def vacate(self, vacated_date):
        self.is_active = False
        self.vacated_date = vacated_date
        self.save()
        self.room.update_status()

class RoomChangeRequest(models.Model):
    STATUS_CHOICES = (
        ('pending', 'Pending'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    )
    
    student = models.ForeignKey(StudentProfile, on_delete=models.CASCADE, related_name='room_change_requests')
    current_room = models.ForeignKey(Room, on_delete=models.CASCADE, related_name='change_requests_from')
    requested_room = models.ForeignKey(Room, on_delete=models.CASCADE, related_name='change_requests_to', 
                                      null=True, blank=True)
    requested_block = models.ForeignKey(HostelBlock, on_delete=models.CASCADE, 
                                       null=True, blank=True)
    reason = models.TextField()
    request_date = models.DateTimeField(auto_now_add=True)
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='pending')
    processed_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True,
                                   limit_choices_to={'user_type__in': ['warden', 'admin']})
    processed_date = models.DateTimeField(null=True, blank=True)
    remarks = models.TextField(null=True, blank=True)
    
    def __str__(self):
        return f"{self.student.user.username} - {self.current_room} to {self.requested_room or 'Any'}"
