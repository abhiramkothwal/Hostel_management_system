from django import forms
from django.utils import timezone
from .models import Room, RoomAllocation, RoomChangeRequest, HostelBlock
from accounts.models import StudentProfile

class RoomFilterForm(forms.Form):
    """Form for filtering rooms by various criteria"""
    hostel_block = forms.ModelChoiceField(
        queryset=HostelBlock.objects.all(),
        required=False,
        empty_label="All Blocks"
    )
    floor = forms.IntegerField(
        required=False,
        min_value=1,
        widget=forms.NumberInput(attrs={'placeholder': 'Floor Number'})
    )
    room_type = forms.ChoiceField(
        choices=[('', 'All Types')] + list(Room.ROOM_TYPE_CHOICES),
        required=False
    )
    status = forms.ChoiceField(
        choices=[('', 'All Statuses')] + list(Room.STATUS_CHOICES),
        required=False
    )

class RoomAllocationForm(forms.ModelForm):
    """Form for allocating a room to a student"""
    student = forms.ModelChoiceField(
        queryset=StudentProfile.objects.filter(
            user__is_active=True,
        ),
        empty_label="Select Student"
    )
    
    class Meta:
        model = RoomAllocation
        fields = ['student']
        
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        
        # Filter student queryset to show only those without active allocations
        students_with_allocations = RoomAllocation.objects.filter(
            is_active=True
        ).values_list('student_id', flat=True)
        
        self.fields['student'].queryset = StudentProfile.objects.filter(
            user__is_active=True
        ).exclude(id__in=students_with_allocations)

class RoomAllocationAdminForm(forms.ModelForm):
    class Meta:
        model = RoomAllocation
        fields = ('student', 'room', 'is_active')
        
    def clean(self):
        cleaned_data = super().clean()
        room = cleaned_data.get('room')
        is_active = cleaned_data.get('is_active')
        
        if is_active and room:
            # Check if room is full
            active_allocations = room.allocations.filter(is_active=True).count()
            if active_allocations >= room.capacity:
                raise forms.ValidationError(f"Room {room} is already at full capacity.")
        
        return cleaned_data

class RoomChangeRequestForm(forms.ModelForm):
    """Form for requesting a room change"""
    requested_room = forms.ModelChoiceField(
        queryset=Room.objects.filter(status__in=['available', 'partially_occupied']),
        required=False,
        empty_label="Any Available Room"
    )
    
    class Meta:
        model = RoomChangeRequest
        fields = ['requested_room', 'requested_block', 'reason']
        widgets = {
            'reason': forms.Textarea(attrs={'rows': 4}),
        }
    
    def __init__(self, *args, **kwargs):
        self.student = kwargs.pop('student', None)
        super().__init__(*args, **kwargs)
        
        # Update available room queryset
        self.fields['requested_room'].queryset = Room.objects.filter(
            status__in=['available', 'partially_occupied']
        ).exclude(
            allocations__student=self.student,
            allocations__is_active=True
        )
        
    def save(self, commit=True):
        instance = super().save(commit=False)
        
        if self.student:
            instance.student = self.student
            
            # Get current room allocation
            current_allocation = RoomAllocation.objects.filter(
                student=self.student,
                is_active=True
            ).first()
            
            if current_allocation:
                instance.current_room = current_allocation.room
        
        if commit:
            instance.save()
        
        return instance

class VacateRoomForm(forms.Form):
    """Form for vacating a room"""
    vacated_date = forms.DateField(
        initial=timezone.now().date(),
        widget=forms.DateInput(attrs={'type': 'date'})
    )
    
    def clean_vacated_date(self):
        vacated_date = self.cleaned_data.get('vacated_date')
        
        if vacated_date and vacated_date > timezone.now().date():
            raise forms.ValidationError("Vacated date cannot be in the future.")
        
        return vacated_date

class DirectRoomRequestForm(forms.ModelForm):
    """Form for directly requesting a specific room from the room list view"""
    
    class Meta:
        model = RoomChangeRequest
        fields = ['reason']
        widgets = {
            'reason': forms.Textarea(attrs={
                'rows': 3, 
                'placeholder': 'Please provide a reason for requesting this room',
                'class': 'form-control'
            }),
        }
    
    def __init__(self, *args, **kwargs):
        self.student = kwargs.pop('student', None)
        self.requested_room = kwargs.pop('requested_room', None)
        super().__init__(*args, **kwargs)
        
        # Check if student has a current room
        has_current_room = RoomAllocation.objects.filter(
            student=self.student,
            is_active=True
        ).exists() if self.student else False
        
        if has_current_room:
            self.fields['reason'].label = "Reason for Changing Room"
            self.fields['reason'].widget.attrs['placeholder'] = "Please provide a reason for changing to this room"
        else:
            self.fields['reason'].label = "Reason for Room Request"
            self.fields['reason'].widget.attrs['placeholder'] = "Please provide a reason for requesting this room"
    
    def save(self, commit=True):
        instance = super().save(commit=False)
        
        if commit:
            instance.save()
        
        return instance 