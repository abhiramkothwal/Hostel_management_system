from django.urls import path
from . import views

urlpatterns = [
    # Room management
    path('', views.room_list, name='room_list'),
    path('<int:room_id>/', views.room_detail, name='room_detail'),
    path('<int:room_id>/allocate/', views.allocate_room, name='allocate_room'),
    path('<int:room_id>/request/', views.direct_room_request, name='direct_room_request'),
    path('allocation/<int:allocation_id>/vacate/', views.vacate_room, name='vacate_room'),
    
    # Room change requests
    path('change-request/', views.room_change_request, name='room_change_request'),
    path('change-request/<int:request_id>/', views.change_request_detail, name='change_request_detail'),
    path('change-request/<int:request_id>/process/', views.process_change_request, name='process_change_request'),
    path('my-change-requests/', views.my_change_requests, name='my_change_requests'),
    
    # Hostel blocks
    path('blocks/', views.block_list, name='block_list'),
    path('blocks/<int:block_id>/', views.block_detail, name='block_detail'),
    
    # Allocations
    path('allocations/', views.allocation_list, name='allocation_list'),
] 