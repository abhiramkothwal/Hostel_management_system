from django.contrib import admin
from .models import HostelBlock, Room, RoomAllocation, RoomChangeRequest

class RoomInline(admin.TabularInline):
    model = Room
    extra = 1

class HostelBlockAdmin(admin.ModelAdmin):
    list_display = ('name', 'warden', 'floors', 'room_count')
    search_fields = ('name', 'warden__username')
    inlines = [RoomInline]
    
    def room_count(self, obj):
        return obj.rooms.count()
    room_count.short_description = 'Number of Rooms'

class RoomAdmin(admin.ModelAdmin):
    list_display = ('room_number', 'hostel_block', 'floor', 'room_type', 'capacity', 'status', 'current_occupancy_display')
    list_filter = ('hostel_block', 'floor', 'room_type', 'status')
    search_fields = ('room_number', 'hostel_block__name')
    
    def current_occupancy_display(self, obj):
        return f"{obj.current_occupancy()} / {obj.capacity}"
    current_occupancy_display.short_description = 'Occupancy'

class RoomAllocationAdmin(admin.ModelAdmin):
    list_display = ('student', 'room', 'allocated_date', 'is_active')
    list_filter = ('is_active', 'allocated_date', 'room__hostel_block')
    search_fields = ('student__user__username', 'room__room_number', 'room__hostel_block__name')
    date_hierarchy = 'allocated_date'

class RoomChangeRequestAdmin(admin.ModelAdmin):
    list_display = ('student', 'current_room', 'requested_room', 'status', 'request_date')
    list_filter = ('status', 'request_date')
    search_fields = ('student__user__username', 'current_room__room_number', 'requested_room__room_number')
    date_hierarchy = 'request_date'
    readonly_fields = ('request_date',)

admin.site.register(HostelBlock, HostelBlockAdmin)
admin.site.register(Room, RoomAdmin)
admin.site.register(RoomAllocation, RoomAllocationAdmin)
admin.site.register(RoomChangeRequest, RoomChangeRequestAdmin)
