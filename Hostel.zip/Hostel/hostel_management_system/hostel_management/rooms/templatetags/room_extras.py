from django import template

register = template.Library()

@register.filter
def sub(value, arg):
    """Subtract the arg from the value"""
    try:
        return int(value) - int(arg)
    except (ValueError, TypeError):
        return 0

@register.filter
def filter_floor(rooms, floor_num):
    """Filter rooms by floor number"""
    return [room for room in rooms if str(room.floor) == str(floor_num)]

@register.filter
def dictsortby(value, arg):
    """Sort a list of dictionaries or objects by attribute"""
    return sorted(value, key=lambda x: getattr(x, arg)) 