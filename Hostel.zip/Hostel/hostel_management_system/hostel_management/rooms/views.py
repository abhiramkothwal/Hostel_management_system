from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import HttpResponseForbidden
from django.utils import timezone
from django.urls import reverse
from .models import Room, HostelBlock, RoomAllocation, RoomChangeRequest
from .forms import RoomFilterForm, RoomAllocationForm, RoomChangeRequestForm, VacateRoomForm, DirectRoomRequestForm
from accounts.models import StudentProfile

@login_required
def room_list(request):
    """Display list of available rooms with filtering options"""
    rooms = Room.objects.all()
    form = RoomFilterForm(request.GET or None)
    
    if form.is_valid():
        if form.cleaned_data.get('hostel_block'):
            rooms = rooms.filter(hostel_block=form.cleaned_data['hostel_block'])
        if form.cleaned_data.get('floor'):
            rooms = rooms.filter(floor=form.cleaned_data['floor'])
        if form.cleaned_data.get('room_type'):
            rooms = rooms.filter(room_type=form.cleaned_data['room_type'])
        if form.cleaned_data.get('status'):
            rooms = rooms.filter(status=form.cleaned_data['status'])
    
    # For student users, check if they can request a room
    can_request_room = False
    has_pending_request = False
    current_room = None
    
    if request.user.is_student():
        try:
            student_profile = request.user.student_profile
            
            # Check if student already has an active room
            current_allocation = RoomAllocation.objects.filter(
                student=student_profile,
                is_active=True
            ).first()
            
            if current_allocation:
                current_room = current_allocation.room
            
            # Check if student already has a pending request
            pending_request = RoomChangeRequest.objects.filter(
                student=student_profile,
                status='pending'
            ).exists()
            
            if pending_request:
                has_pending_request = True
            
            # Student can request if they have a profile, regardless of whether they have a room
            can_request_room = True
            
        except StudentProfile.DoesNotExist:
            can_request_room = False
    
    return render(request, 'rooms/room_list.html', {
        'rooms': rooms,
        'form': form,
        'can_request_room': can_request_room,
        'has_pending_request': has_pending_request,
        'current_room': current_room,
    })

@login_required
def room_detail(request, room_id):
    """Display details of a specific room"""
    room = get_object_or_404(Room, pk=room_id)
    allocations = RoomAllocation.objects.filter(room=room, is_active=True)
    
    # Check if current user is a student with a profile
    current_student_allocation = None
    if request.user.is_student():
        try:
            student_profile = request.user.student_profile
            current_student_allocation = RoomAllocation.objects.filter(
                student=student_profile,
                is_active=True
            ).first()
        except StudentProfile.DoesNotExist:
            pass
    
    return render(request, 'rooms/room_detail.html', {
        'room': room,
        'allocations': allocations,
        'current_student_allocation': current_student_allocation,
    })

@login_required
def allocate_room(request, room_id):
    """Allocate a room to a student (admin/warden only)"""
    if not (request.user.is_warden() or request.user.is_hostel_admin()):
        return HttpResponseForbidden("You don't have permission to allocate rooms.")
    
    room = get_object_or_404(Room, pk=room_id)
    
    # Check if room is available
    current_occupancy = room.current_occupancy()
    if current_occupancy >= room.capacity:
        messages.error(request, f"Room {room.room_number} is already at full capacity.")
        return redirect('room_detail', room_id=room.id)
    
    if request.method == 'POST':
        form = RoomAllocationForm(request.POST)
        if form.is_valid():
            allocation = form.save(commit=False)
            allocation.room = room
            allocation.save()
            
            messages.success(request, f"Room allocated successfully to {allocation.student.user.username}.")
            return redirect('room_detail', room_id=room.id)
    else:
        form = RoomAllocationForm(initial={'room': room})
    
    return render(request, 'rooms/allocate_room.html', {
        'form': form,
        'room': room,
    })

@login_required
def vacate_room(request, allocation_id):
    """Vacate a room allocation"""
    allocation = get_object_or_404(RoomAllocation, pk=allocation_id)
    
    # Only admin/warden or the student themselves can vacate
    if not (request.user.is_warden() or request.user.is_hostel_admin() or 
            (request.user.is_student() and hasattr(request.user, 'student_profile') and 
             request.user.student_profile == allocation.student)):
        return HttpResponseForbidden("You don't have permission to vacate this room.")
    
    if request.method == 'POST':
        form = VacateRoomForm(request.POST)
        if form.is_valid():
            vacated_date = form.cleaned_data['vacated_date']
            allocation.vacate(vacated_date)
            
            messages.success(request, "Room has been vacated successfully.")
            return redirect('room_detail', room_id=allocation.room.id)
    else:
        form = VacateRoomForm(initial={'vacated_date': timezone.now().date()})
    
    return render(request, 'rooms/vacate_room.html', {
        'form': form,
        'allocation': allocation,
    })

@login_required
def room_change_request(request):
    """Create a new room change request (students only)"""
    if not request.user.is_student():
        return HttpResponseForbidden("Only students can request room changes.")
    
    try:
        student_profile = request.user.student_profile
    except StudentProfile.DoesNotExist:
        messages.error(request, "You need to complete your student profile first.")
        return redirect('edit_profile')
    
    # Check if student has an active room allocation
    current_allocation = RoomAllocation.objects.filter(
        student=student_profile,
        is_active=True
    ).first()
    
    if not current_allocation:
        messages.error(request, "You need to have an active room allocation to request a change.")
        return redirect('room_list')
    
    # Check for existing pending requests
    existing_request = RoomChangeRequest.objects.filter(
        student=student_profile,
        status='pending'
    ).first()
    
    if existing_request:
        messages.info(request, "You already have a pending room change request.")
        return redirect('change_request_detail', request_id=existing_request.id)
    
    if request.method == 'POST':
        form = RoomChangeRequestForm(request.POST, student=student_profile)
        if form.is_valid():
            change_request = form.save()
            
            messages.success(request, "Your room change request has been submitted successfully.")
            return redirect('my_change_requests')
    else:
        form = RoomChangeRequestForm(student=student_profile)
    
    return render(request, 'rooms/room_change_request.html', {
        'form': form,
        'current_room': current_allocation.room,
    })

@login_required
def change_request_detail(request, request_id):
    """View details of a room change request"""
    change_request = get_object_or_404(RoomChangeRequest, pk=request_id)
    
    # Only admin/warden or the student who made the request can view it
    if not (request.user.is_warden() or request.user.is_hostel_admin() or 
            (request.user.is_student() and hasattr(request.user, 'student_profile') and 
             request.user.student_profile == change_request.student)):
        return HttpResponseForbidden("You don't have permission to view this request.")
    
    return render(request, 'rooms/change_request_detail.html', {
        'change_request': change_request,
    })

@login_required
def process_change_request(request, request_id):
    """Process a room change request (admin/warden only)"""
    if not (request.user.is_warden() or request.user.is_hostel_admin()):
        return HttpResponseForbidden("You don't have permission to process room change requests.")
    
    change_request = get_object_or_404(RoomChangeRequest, pk=request_id)
    
    if change_request.status != 'pending':
        messages.error(request, "This request has already been processed.")
        return redirect('change_request_detail', request_id=change_request.id)
    
    if request.method == 'POST':
        status = request.POST.get('status')
        remarks = request.POST.get('remarks', '')
        
        if status in ['approved', 'rejected']:
            change_request.status = status
            change_request.processed_by = request.user
            change_request.processed_date = timezone.now()
            change_request.remarks = remarks
            change_request.save()
            
            if status == 'approved' and change_request.requested_room:
                # Vacate current room
                current_allocation = RoomAllocation.objects.get(
                    student=change_request.student,
                    room=change_request.current_room,
                    is_active=True
                )
                current_allocation.vacate(timezone.now().date())
                
                # Create new allocation
                RoomAllocation.objects.create(
                    student=change_request.student,
                    room=change_request.requested_room,
                    is_active=True
                )
            
            messages.success(request, f"Room change request has been {status}.")
            return redirect('change_request_detail', request_id=change_request.id)
    
    return render(request, 'rooms/process_change_request.html', {
        'change_request': change_request,
    })

@login_required
def my_change_requests(request):
    """View student's own room change requests"""
    if not request.user.is_student():
        return HttpResponseForbidden("Only students can view their room change requests.")
    
    try:
        student_profile = request.user.student_profile
        change_requests = RoomChangeRequest.objects.filter(student=student_profile).order_by('-request_date')
    except StudentProfile.DoesNotExist:
        change_requests = []
    
    return render(request, 'rooms/my_change_requests.html', {
        'change_requests': change_requests,
    })

@login_required
def block_list(request):
    """List all hostel blocks (admin/warden only)"""
    if not (request.user.is_warden() or request.user.is_hostel_admin()):
        return HttpResponseForbidden("You don't have permission to view hostel blocks.")
    
    blocks = HostelBlock.objects.all()
    
    return render(request, 'rooms/block_list.html', {
        'blocks': blocks,
    })

@login_required
def block_detail(request, block_id):
    """View details of a hostel block (admin/warden only)"""
    if not (request.user.is_warden() or request.user.is_hostel_admin()):
        return HttpResponseForbidden("You don't have permission to view hostel block details.")
    
    block = get_object_or_404(HostelBlock, pk=block_id)
    rooms = Room.objects.filter(hostel_block=block)
    
    # Group rooms by floor
    rooms_by_floor = {}
    for room in rooms:
        if room.floor not in rooms_by_floor:
            rooms_by_floor[room.floor] = []
        rooms_by_floor[room.floor].append(room)
    
    return render(request, 'rooms/block_detail.html', {
        'block': block,
        'rooms_by_floor': rooms_by_floor,
    })

@login_required
def allocation_list(request):
    """List all room allocations (admin/warden only)"""
    if not (request.user.is_warden() or request.user.is_hostel_admin()):
        return HttpResponseForbidden("You don't have permission to view room allocations.")
    
    allocations = RoomAllocation.objects.filter(is_active=True).order_by('room__hostel_block', 'room__floor', 'room__room_number')
    
    # Get recent change requests
    change_requests = RoomChangeRequest.objects.filter(status='pending').order_by('-request_date')[:10]
    
    # Calculate unique values
    unique_students = set(allocation.student_id for allocation in allocations)
    unique_rooms = set(allocation.room_id for allocation in allocations)
    unique_blocks = set(allocation.room.hostel_block_id for allocation in allocations)
    
    return render(request, 'rooms/allocation_list.html', {
        'allocations': allocations,
        'change_requests': change_requests,
        'unique_students': len(unique_students),
        'unique_rooms': len(unique_rooms),
        'unique_blocks': len(unique_blocks),
    })

@login_required
def direct_room_request(request, room_id):
    """Handle a direct room request from the room list view"""
    if not request.user.is_student():
        return HttpResponseForbidden("Only students can request rooms.")
    
    room = get_object_or_404(Room, pk=room_id)
    
    # Check if room is available for allocation
    if room.status not in ['available', 'partially_occupied']:
        messages.error(request, f"Room {room.room_number} is not available for allocation.")
        return redirect('room_list')
    
    try:
        student_profile = request.user.student_profile
    except StudentProfile.DoesNotExist:
        messages.error(request, "You need to complete your student profile first.")
        return redirect('edit_profile')
    
    # Check for existing pending requests
    existing_request = RoomChangeRequest.objects.filter(
        student=student_profile,
        status='pending'
    ).first()
    
    if existing_request:
        messages.info(request, "You already have a pending room request.")
        return redirect('change_request_detail', request_id=existing_request.id)
    
    # Check if student already has a room
    current_allocation = RoomAllocation.objects.filter(
        student=student_profile,
        is_active=True
    ).first()
    
    if request.method == 'POST':
        form = DirectRoomRequestForm(request.POST, student=student_profile, requested_room=room)
        if form.is_valid():
            room_request = form.save(commit=False)
            room_request.student = student_profile
            room_request.requested_room = room
            
            # If student doesn't have a current room, we'll use the requested room as a placeholder
            # This is needed because current_room field is required in the model
            if current_allocation:
                room_request.current_room = current_allocation.room
            else:
                # Using requested room as the current room for new students
                room_request.current_room = room
            
            room_request.save()
            
            # Notify wardens
            warden = room.hostel_block.warden
            if warden:
                # Here you could add notification logic for the warden
                pass
            
            messages.success(request, 
                f"Your request for room {room.room_number} in {room.hostel_block.name} has been submitted and is awaiting approval.")
            return redirect('my_change_requests')
    else:
        form = DirectRoomRequestForm(student=student_profile, requested_room=room)
    
    return render(request, 'rooms/direct_room_request.html', {
        'form': form,
        'room': room,
        'has_current_room': current_allocation is not None,
    })
