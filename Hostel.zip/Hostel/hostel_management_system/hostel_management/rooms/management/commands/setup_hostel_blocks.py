from django.core.management.base import BaseCommand
from django.db import transaction
from rooms.models import HostelBlock, Room
from accounts.models import User
import random

class Command(BaseCommand):
    help = 'Sets up the hostel blocks with rooms'

    def handle(self, *args, **kwargs):
        # Define the blocks
        blocks = [
            {"name": "Hemavathi Block", "floors": 3},
            {"name": "Sharvathi Block", "floors": 3},
            {"name": "Kaveri Block", "floors": 3},
            {"name": "Yamuna Block", "floors": 3},
            {"name": "Tunga Block", "floors": 3},
            {"name": "Bhadra Block", "floors": 3},
        ]
        
        # Room types with their capacities
        room_types = [
            {'type': 'single', 'capacity': 1},
            {'type': 'double', 'capacity': 2},
            {'type': 'triple', 'capacity': 3},
            {'type': 'quad', 'capacity': 4},
        ]
        
        # Possible facilities
        facilities = [
            'Attached Bathroom', 
            'Study Table', 
            'Wardrobe', 
            'Air Conditioning',
            'Hot Water',
            'Balcony',
            'Extra Spacious',
            'Premium Furniture'
        ]
        
        # Get or create a warden user for each block
        wardens = []
        for i in range(len(blocks)):
            username = f"warden{i+1}"
            email = f"warden{i+1}@example.com"
            
            warden, created = User.objects.get_or_create(
                username=username,
                defaults={
                    'email': email,
                    'first_name': f"Warden {i+1}",
                    'last_name': "Supervisor",
                    'user_type': 'warden',
                    'is_active': True
                }
            )
            
            if created:
                warden.set_password("password123")
                warden.save()
                self.stdout.write(self.style.SUCCESS(f"Created warden user: {username}"))
            else:
                self.stdout.write(f"Using existing warden user: {username}")
                
            wardens.append(warden)
        
        try:
            with transaction.atomic():
                # Create blocks
                for i, block_data in enumerate(blocks):
                    block, created = HostelBlock.objects.get_or_create(
                        name=block_data["name"],
                        defaults={
                            'floors': block_data["floors"],
                            'warden': wardens[i % len(wardens)],
                            'description': f"Student accommodation at {block_data['name']}"
                        }
                    )
                    
                    if created:
                        self.stdout.write(self.style.SUCCESS(f"Created block: {block.name}"))
                    else:
                        self.stdout.write(f"Block already exists: {block.name}")
                        # Update the block with the newest warden
                        block.warden = wardens[i % len(wardens)]
                        block.save()
                        
                    # Create rooms for this block
                    for floor in range(1, block_data["floors"] + 1):
                        # Create 25 rooms per floor
                        for room_num in range(1, 26):
                            # Format room number as BlockInitial-Floor-RoomNum (e.g., H-1-01)
                            block_initial = block.name[0].upper()
                            room_number = f"{block_initial}-{floor}-{room_num:02d}"
                            
                            # Randomly assign room type
                            room_type_data = random.choice(room_types)
                            
                            # Random set of facilities (between 2 and 5)
                            num_facilities = random.randint(2, 5)
                            room_facilities = ', '.join(random.sample(facilities, num_facilities))
                            
                            # Create room
                            room, created = Room.objects.get_or_create(
                                room_number=room_number,
                                hostel_block=block,
                                defaults={
                                    'floor': floor,
                                    'room_type': room_type_data['type'],
                                    'capacity': room_type_data['capacity'],
                                    'facilities': room_facilities,
                                    'status': 'available'
                                }
                            )
                            
                            if created:
                                self.stdout.write(f"  Created room: {room.room_number}")
                            else:
                                self.stdout.write(f"  Room already exists: {room.room_number}")
                                
                self.stdout.write(self.style.SUCCESS("Hostel blocks and rooms setup completed successfully"))
                
        except Exception as e:
            self.stdout.write(self.style.ERROR(f"Error setting up hostel blocks: {e}")) 