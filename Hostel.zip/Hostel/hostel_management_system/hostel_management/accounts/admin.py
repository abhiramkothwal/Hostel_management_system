from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import User, StudentProfile, WardenProfile

class CustomUserAdmin(UserAdmin):
    fieldsets = UserAdmin.fieldsets + (
        ('Additional Info', {'fields': ('user_type', 'profile_picture')}),
    )
    list_display = ('username', 'email', 'first_name', 'last_name', 'user_type', 'is_staff')
    list_filter = UserAdmin.list_filter + ('user_type',)
    search_fields = ('username', 'email', 'first_name', 'last_name')

class StudentProfileAdmin(admin.ModelAdmin):
    list_display = ('get_username', 'student_id', 'department', 'year_of_study', 'phone_number')
    search_fields = ('user__username', 'student_id', 'department')
    list_filter = ('department', 'year_of_study')
    
    def get_username(self, obj):
        return obj.user.username
    get_username.short_description = 'Username'
    get_username.admin_order_field = 'user__username'

class WardenProfileAdmin(admin.ModelAdmin):
    list_display = ('get_username', 'employee_id', 'designation', 'phone_number', 'date_of_joining')
    search_fields = ('user__username', 'employee_id', 'designation')
    
    def get_username(self, obj):
        return obj.user.username
    get_username.short_description = 'Username'
    get_username.admin_order_field = 'user__username'

admin.site.register(User, CustomUserAdmin)
admin.site.register(StudentProfile, StudentProfileAdmin)
admin.site.register(WardenProfile, WardenProfileAdmin)
