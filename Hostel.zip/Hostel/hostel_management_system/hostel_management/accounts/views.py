from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.contrib.auth.tokens import default_token_generator
from django.utils.http import urlsafe_base64_encode, urlsafe_base64_decode
from django.utils.encoding import force_bytes
from django.urls import reverse
from django.core.mail import send_mail
from django.template.loader import render_to_string
from django.conf import settings
from .forms import (
    CustomUserCreationForm, 
    CustomAuthenticationForm,
    StudentProfileForm,
    WardenProfileForm,
    UserProfileForm,
    PasswordResetForm,
    PasswordChangeRequestForm
)
from .models import User, StudentProfile, WardenProfile
from dashboard.models import Notification

def user_login(request):
    if request.user.is_authenticated:
        return redirect('dashboard')
        
    if request.method == 'POST':
        form = CustomAuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                messages.success(request, f"Welcome back, {user.username}!")
                
                # Get the next parameter or default to dashboard
                next_page = request.GET.get('next', 'dashboard')
                return redirect(next_page)
            else:
                messages.error(request, "Invalid username or password.")
        else:
            messages.error(request, "Invalid username or password.")
    else:
        form = CustomAuthenticationForm()
    
    return render(request, 'accounts/login.html', {'form': form})

def user_logout(request):
    logout(request)
    messages.success(request, "You have been logged out successfully.")
    return redirect('home')

def register(request):
    if request.user.is_authenticated:
        return redirect('dashboard')
        
    if request.method == 'POST':
        user_form = CustomUserCreationForm(request.POST)
        profile_form = None
        student_form = None
        warden_form = None
        
        user_type = request.POST.get('user_type')
        
        if user_type == 'student':
            profile_form = StudentProfileForm(request.POST)
            student_form = profile_form
        elif user_type == 'warden':
            profile_form = WardenProfileForm(request.POST)
            warden_form = profile_form
        
        if user_form.is_valid() and (profile_form is None or profile_form.is_valid()):
            try:
                user = user_form.save()
                
                if profile_form:
                    profile = profile_form.save(commit=False)
                    profile.user = user
                    profile.save()
                    
                # Create a welcome notification
                Notification.objects.create(
                    user=user,
                    title="Welcome to Smart Hostel Management System",
                    message="Thank you for registering. Explore our features to make the most of your hostel experience.",
                    link=reverse('dashboard')
                )
                    
                messages.success(request, "Your account has been created successfully. You can now login.")
                return redirect('login')
            except Exception as e:
                # Handle database integrity errors
                if 'UNIQUE constraint' in str(e) and 'username' in str(e):
                    user_form.add_error('username', "This username is already taken. Please choose a different username.")
                else:
                    messages.error(request, f"An error occurred during registration: {str(e)}")
        else:
            # Form validation error handling
            if not user_form.is_valid():
                for field, errors in user_form.errors.items():
                    for error in errors:
                        messages.error(request, f"{field}: {error}")
            
            if profile_form and not profile_form.is_valid():
                for field, errors in profile_form.errors.items():
                    for error in errors:
                        messages.error(request, f"{field}: {error}")
    else:
        user_form = CustomUserCreationForm()
        student_form = StudentProfileForm()
        warden_form = WardenProfileForm()
    
    return render(request, 'accounts/register.html', {
        'user_form': user_form,
        'student_form': student_form,
        'warden_form': warden_form
    })

@login_required
def profile(request):
    user = request.user
    
    if user.is_student():
        try:
            profile = user.student_profile
        except StudentProfile.DoesNotExist:
            profile = None
    elif user.is_warden():
        try:
            profile = user.warden_profile
        except WardenProfile.DoesNotExist:
            profile = None
    else:
        profile = None
    
    return render(request, 'accounts/profile.html', {
        'user': user,
        'profile': profile
    })

@login_required
def edit_profile(request):
    user = request.user
    
    if request.method == 'POST':
        user_form = UserProfileForm(request.POST, request.FILES, instance=user)
        
        # Get the correct profile form based on user type
        if user.is_student():
            try:
                profile = user.student_profile
                profile_form = StudentProfileForm(request.POST, instance=profile)
            except StudentProfile.DoesNotExist:
                profile_form = StudentProfileForm(request.POST)
        elif user.is_warden():
            try:
                profile = user.warden_profile
                profile_form = WardenProfileForm(request.POST, instance=profile)
            except WardenProfile.DoesNotExist:
                profile_form = WardenProfileForm(request.POST)
        else:
            profile_form = None
        
        if user_form.is_valid() and (profile_form is None or profile_form.is_valid()):
            user_form.save()
            
            if profile_form:
                profile = profile_form.save(commit=False)
                profile.user = user
                profile.save()
                
            messages.success(request, "Your profile has been updated successfully.")
            return redirect('profile')
    else:
        user_form = UserProfileForm(instance=user)
        
        # Get the correct profile form based on user type
        if user.is_student():
            try:
                profile = user.student_profile
                profile_form = StudentProfileForm(instance=profile)
            except StudentProfile.DoesNotExist:
                profile_form = StudentProfileForm()
        elif user.is_warden():
            try:
                profile = user.warden_profile
                profile_form = WardenProfileForm(instance=profile)
            except WardenProfile.DoesNotExist:
                profile_form = WardenProfileForm()
        else:
            profile_form = None
    
    return render(request, 'accounts/edit_profile.html', {
        'user_form': user_form,
        'profile_form': profile_form,
        'user': user
    })

def password_reset_request(request):
    if request.method == 'POST':
        form = PasswordChangeRequestForm(request.POST)
        if form.is_valid():
            email = form.cleaned_data['email']
            try:
                user = User.objects.get(email=email)
                
                # Generate token and uid
                token = default_token_generator.make_token(user)
                uid = urlsafe_base64_encode(force_bytes(user.pk))
                
                # Build the reset URL
                reset_url = request.build_absolute_uri(
                    reverse('password_reset_confirm', kwargs={'uidb64': uid, 'token': token})
                )
                
                # Send email
                subject = "Password Reset Request"
                message = render_to_string('accounts/password_reset_email.html', {
                    'user': user,
                    'reset_url': reset_url,
                })
                
                send_mail(
                    subject,
                    message,
                    settings.DEFAULT_FROM_EMAIL,
                    [email],
                    fail_silently=False,
                )
                
                messages.success(request, "Password reset instructions have been sent to your email.")
                return redirect('login')
            except User.DoesNotExist:
                # Don't reveal that the user doesn't exist
                messages.success(request, "Password reset instructions have been sent to your email if the account exists.")
                return redirect('login')
    else:
        form = PasswordChangeRequestForm()
    
    return render(request, 'accounts/password_reset_request.html', {'form': form})

def password_reset_confirm(request, uidb64, token):
    try:
        uid = urlsafe_base64_decode(uidb64).decode()
        user = User.objects.get(pk=uid)
    except (TypeError, ValueError, OverflowError, User.DoesNotExist):
        user = None
    
    if user is not None and default_token_generator.check_token(user, token):
        if request.method == 'POST':
            form = PasswordResetForm(request.POST)
            if form.is_valid():
                password = form.cleaned_data['password1']
                user.set_password(password)
                user.save()
                
                messages.success(request, "Your password has been reset successfully. You can now login with your new password.")
                return redirect('login')
        else:
            form = PasswordResetForm()
        
        return render(request, 'accounts/password_reset_confirm.html', {'form': form})
    else:
        messages.error(request, "The password reset link is invalid or has expired.")
        return redirect('password_reset')
    